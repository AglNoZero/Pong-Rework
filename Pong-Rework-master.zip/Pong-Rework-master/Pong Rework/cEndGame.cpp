#include "cEndGame.h"



cEndGame::cEndGame()
{
}


cEndGame::~cEndGame()
{
}
